"""Azure AI OCR module."""
from .transformation import AzureAIOCRConfig

__all__ = ["AzureAIOCRConfig"]

