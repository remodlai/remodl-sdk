"""
LLM Calling done in `openai/openai.py`
"""
