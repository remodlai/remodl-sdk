import types
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Dict, Optional, Tuple, Union

import httpx
from httpx._types import RequestFiles

from remodl.types.videos.main import VideoCreateOptionalRequestParams
from remodl.types.responses.main import *
from remodl.types.router import GenericLiteLLMParams

if TYPE_CHECKING:
    from remodl.remodl_core_utils.remodl_logging import Logging as _LiteLLMLoggingObj
    from remodl.types.videos.main import VideoObject as _VideoObject

    from ..chat.transformation import BaseLLMException as _BaseLLMException

    LiteLLMLoggingObj = _LiteLLMLoggingObj
    BaseLLMException = _BaseLLMException
    VideoObject = _VideoObject
else:
    LiteLLMLoggingObj = Any
    BaseLLMException = Any
    VideoObject = Any


class BaseVideoConfig(ABC):
    def __init__(self):
        pass

    @classmethod
    def get_config(cls):
        return {
            k: v
            for k, v in cls.__dict__.items()
            if not k.startswith("__")
            and not k.startswith("_abc")
            and not isinstance(
                v,
                (
                    types.FunctionType,
                    types.BuiltinFunctionType,
                    classmethod,
                    staticmethod,
                ),
            )
            and v is not None
        }

    @abstractmethod
    def get_supported_openai_params(self, model: str) -> list:
        pass

    @abstractmethod
    def map_openai_params(
        self,
        video_create_optional_params: VideoCreateOptionalRequestParams,
        model: str,
        drop_params: bool,
    ) -> Dict:
        pass

    @abstractmethod
    def validate_environment(
        self,
        headers: dict,
        model: str,
        api_key: Optional[str] = None,
    ) -> dict:
        return {}

    @abstractmethod
    def get_complete_url(
        self,
        model: str,
        api_base: Optional[str],
        remodl_params: dict,
    ) -> str:
        """
        OPTIONAL

        Get the complete url for the request

        Some providers need `model` in `api_base`
        """
        if api_base is None:
            raise ValueError("api_base is required")
        return api_base

    @abstractmethod
    def transform_video_create_request(
        self,
        model: str,
        prompt: str,
        video_create_optional_request_params: Dict,
        remodl_params: GenericLiteLLMParams,
        headers: dict,
    ) -> Tuple[Dict, RequestFiles]:
        pass

    @abstractmethod
    def transform_video_create_response(
        self,
        model: str,
        raw_response: httpx.Response,
        logging_obj: LiteLLMLoggingObj,
    ) -> VideoObject:
        pass

    @abstractmethod
    def transform_video_content_request(
        self,
        video_id: str,
        model: str,
        api_base: str,
        remodl_params: GenericLiteLLMParams,
        headers: dict,
    ) -> Tuple[str, Dict]:
        """
        Transform the video content request into a URL and data/params
        
        Returns:
            Tuple[str, Dict]: (url, params) for the video content request
        """
        pass

    @abstractmethod
    def transform_video_content_response(
        self,
        model: str,
        raw_response: httpx.Response,
        logging_obj: LiteLLMLoggingObj,
    ) -> bytes:
        pass

    @abstractmethod
    def transform_video_remix_request(
        self,
        video_id: str,
        prompt: str,
        model: str,
        api_base: str,
        remodl_params: GenericLiteLLMParams,
        headers: dict,
        extra_body: Optional[Dict[str, Any]] = None,
    ) -> Tuple[str, Dict]:
        """
        Transform the video remix request into a URL and data
        
        Returns:
            Tuple[str, Dict]: (url, data) for the video remix request
        """
        pass

    @abstractmethod
    def transform_video_remix_response(
        self,
        model: str,
        raw_response: httpx.Response,
        logging_obj: LiteLLMLoggingObj,
    ) -> VideoObject:
        pass

    @abstractmethod
    def transform_video_list_request(
        self,
        model: str,
        api_base: str,
        remodl_params: GenericLiteLLMParams,
        headers: dict,
        after: Optional[str] = None,
        limit: Optional[int] = None,
        order: Optional[str] = None,
        extra_query: Optional[Dict[str, Any]] = None,
    ) -> Tuple[str, Dict]:
        """
        Transform the video list request into a URL and params
        
        Returns:
            Tuple[str, Dict]: (url, params) for the video list request
        """
        pass

    @abstractmethod
    def transform_video_list_response(
        self,
        model: str,
        raw_response: httpx.Response,
        logging_obj: LiteLLMLoggingObj,
    ) -> Dict[str,str]:
        pass

    @abstractmethod
    def transform_video_delete_request(
        self,
        video_id: str,
        model: str,
        api_base: str,
        remodl_params: GenericLiteLLMParams,
        headers: dict,
    ) -> Tuple[str, Dict]:
        """
        Transform the video delete request into a URL and data
        
        Returns:
            Tuple[str, Dict]: (url, data) for the video delete request
        """
        pass

    @abstractmethod
    def transform_video_delete_response(
        self,
        model: str,
        raw_response: httpx.Response,
        logging_obj: LiteLLMLoggingObj,
    ) -> VideoObject:
        pass

    @abstractmethod
    def transform_video_status_retrieve_request(
        self,
        video_id: str,
        model: str,
        api_base: str,
        remodl_params: GenericLiteLLMParams,
        headers: dict,
    ) -> Tuple[str, Dict]:
        """
        Transform the video retrieve request into a URL and data/params
        
        Returns:
            Tuple[str, Dict]: (url, params) for the video retrieve request
        """
        pass

    @abstractmethod
    def transform_video_status_retrieve_response(
        self,
        model: str,
        raw_response: httpx.Response,
        logging_obj: LiteLLMLoggingObj,
    ) -> VideoObject:
        pass

    def get_error_class(
        self, error_message: str, status_code: int, headers: Union[dict, httpx.Headers]
    ) -> BaseLLMException:
        from ..chat.transformation import BaseLLMException

        raise BaseLLMException(
            status_code=status_code,
            message=error_message,
            headers=headers,
        )
