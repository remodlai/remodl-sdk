"""Azure Text-to-Speech module"""

from .transformation import AzureAVATextToSpeechConfig

__all__ = [
    "AzureAVATextToSpeechConfig",
]

