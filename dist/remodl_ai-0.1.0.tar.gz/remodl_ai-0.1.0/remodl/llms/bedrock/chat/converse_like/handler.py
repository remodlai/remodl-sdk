"""
Uses base_llm_http_handler to call the 'converse like' endpoint.

Relevant issue: https://github.com/BerriAI/remodl/issues/8085
"""
