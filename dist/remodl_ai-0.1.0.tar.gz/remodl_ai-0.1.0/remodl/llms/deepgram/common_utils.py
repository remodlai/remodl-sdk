from remodl.llms.base_llm.chat.transformation import BaseLLMException


class DeepgramException(BaseLLMException):
    pass
