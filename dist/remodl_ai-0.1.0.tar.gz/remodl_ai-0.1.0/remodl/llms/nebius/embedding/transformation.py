"""
Calls handled in openai/

as Nebius AI Studio is an openai-compatible endpoint.
"""
