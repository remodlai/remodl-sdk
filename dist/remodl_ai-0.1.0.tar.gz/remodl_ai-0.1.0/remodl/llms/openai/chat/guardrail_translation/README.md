Translation of OpenAI `/chat/completions` input and output to a custom guardrail.

This enables guardrails to be applied to OpenAI `/chat/completions` requests and responses.