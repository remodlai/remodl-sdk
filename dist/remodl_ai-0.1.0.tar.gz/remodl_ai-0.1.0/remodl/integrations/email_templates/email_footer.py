EMAIL_FOOTER = """
<div class="footer">
            <p>© 2025 LiteLLM. All rights reserved.</p>
            <div class="social-links">
                <a href="https://twitter.com/remodl">Twitter</a> • 
                <a href="https://github.com/BerriAI/remodl">GitHub</a> • 
                <a href="https://remodl.ai">Website</a>
            </div>
</div>
"""
