from remodl.integrations.custom_prompt_management import CustomPromptManagement


class BaseVectorStore(CustomPromptManagement):
    pass
