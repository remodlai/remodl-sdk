Logic specific for `remodl.completion`. 

Includes:
- Bridge for transforming completion requests to responses api requests